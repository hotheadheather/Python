#Bug collector- This is a for loop that add up the number of bugs you collect within a 7 day period.
#Heather Whittlesey
#10/7/19



maxDays = 7

tot = 0

print('How many bugs did you collect today?')

for counter in range(maxDays):
    number = int(input('Enter your bugs: '))
    tot = tot + number

    print('The total number of bugs you collected were', tot)

